
import java.io.IOException;
public class Agent extends ShipmentEntity {
private String fmc;
private String iata;
public Agent(String name, String accountNumber, String address,String fmc, String iata ) {
super(name,accountNumber,address);
 this.fmc=fmc;	
 this.iata=iata;
}
public String toString() {
    return String.format("\"name\" : \""+getName()+"\",\n"+"\"account-number\" : \""+getAccountNumber()+"\",\n"+"\"address\" : \""+getAddress()+"\",\n"+"\"fmc\" : \""+getFmc()+"\",\n"+"\"iata\" : \""+getIata()+"\"");
} 
public String getFmc() {
return fmc;
}
public void setFmc(String fmc) {
this.fmc = fmc;
}
public String getIata() {
return iata;
}
public void setIata(String iata) {
this.iata = iata;
}
void displayAgentDetails()
{
	System.out.println("agent = '{");
	System.out.println(toString());
	System.out.println("}';");
	
	
}
}
