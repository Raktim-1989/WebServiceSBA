
import java.io.*;
public class Main {
public static void main(String[] args) throws Exception {
int choice;
String name,accountNumber,address,fmc,iata,identificationNumber;
BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
System.out.println("1. Agent\n2. Customer\nEnter the choice :");
choice = Integer.parseInt(br.readLine());
System.out.println("Enter the name :");
name = br.readLine();
System.out.println("Enter the account number :");
accountNumber = br.readLine();
System.out.println("Enter the address :");
address = br.readLine();
switch(choice)
{
case 1:
System.out.println("Enter the fmc :");
fmc = br.readLine();
System.out.println("Enter the iata code :");
iata = br.readLine();
System.out.println("JSON Format :");
//fill the code
Agent a = new Agent(name,accountNumber,address,fmc,iata);
a.displayAgentDetails();
break;
case 2:
System.out.println("Enter the identification number :");
identificationNumber = br.readLine();
System.out.println("JSON Format :");
//fill the code
Customer c = new Customer( name,  accountNumber,  address, identificationNumber);
c.displayCustomerDetails();
break;
}
}
}
