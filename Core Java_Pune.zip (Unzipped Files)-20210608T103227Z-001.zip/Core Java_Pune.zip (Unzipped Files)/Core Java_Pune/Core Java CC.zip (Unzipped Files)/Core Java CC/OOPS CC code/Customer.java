import java.io.IOException;

public class Customer extends ShipmentEntity {
private String identificationNumber;
public Customer(String name, String accountNumber, String address,String identificationNumber) {
//fill the code
	super(name,accountNumber,address);
	this.identificationNumber=identificationNumber;
}
public String toString() {
	return String.format("\"name\" : \""+getName()+"\",\n"+"\"account-number\" : \""+getAccountNumber()+"\",\n"+"\"address\" : \""+getAddress()+"\",\n"+"\"identification-number\" : \""+getIdentificationNumber()+"\"");
} 
public String getIdentificationNumber() {
return identificationNumber;
}
public void setIdentificationNumber(String identificationNumber) {
this.identificationNumber = identificationNumber;
}
void displayCustomerDetails()
{
//fill the code
	System.out.println("customer = '{");
	System.out.println(toString());
	System.out.println("}';");
}
}
