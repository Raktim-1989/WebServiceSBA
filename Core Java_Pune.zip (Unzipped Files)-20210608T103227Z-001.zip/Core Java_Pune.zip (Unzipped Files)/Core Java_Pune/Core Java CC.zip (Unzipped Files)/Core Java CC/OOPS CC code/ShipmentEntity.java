
public class ShipmentEntity {
private String name;


private String accountNumber;
private String address;


public ShipmentEntity(String name, String accountNumber, String address) {
this.name = name;
this.accountNumber = accountNumber;
this.address = address;

}

public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public String getAccountNumber() {
return accountNumber;
}
public void setAccountNumber(String accountNumber) {
this.accountNumber = accountNumber;
}
public String getAddress() {
return address;
}
public void setAddress(String address) {
this.address = address;
}
}
